﻿using DataAccess.Repository;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SalesWPFApp
{
    /// <summary>
    /// Interaction logic for WindowLogin.xaml
    /// </summary>
    public partial class WindowLogin : Window
    {
        private readonly IMemberRepository memberRepo;
        private readonly IOrderRepository orderRepo;
        private readonly IProductRepository productRepo;
        /*private readonly IOrderDetailRepository orderDetailRepo;*/
        public WindowLogin(
            IMemberRepository _memberRepo,
            IOrderRepository _orderRepo,
            IProductRepository _productRepo)
        {
            InitializeComponent();
            memberRepo = _memberRepo;
            orderRepo = _orderRepo;
            productRepo = _productRepo;
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e) => Close();

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string username=txtUsername.Text;
            string password = txtPassword.Password;

            var checkUser = memberRepo.verifyMember(username, password);

            var conf = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            var usernameDefault = conf["defaultAccount:email"];
            var passwordDefault = conf["defaultAccount:password"];

            string role;
            if(username == usernameDefault && password == passwordDefault)
            {
                role = "admin";
                MessageBox.Show("Login as admin successfully");
            }else if (checkUser != null)
            {
                role = "member";
                MessageBox.Show("Login as normal user");
            }
            else
            {
                MessageBox.Show("Invalid username or password");
                return;
            }
            Application.Current.Properties["role"] = role;
            Application.Current.Properties["member"] = checkUser;

            MainWindow view = new MainWindow(memberRepo, orderRepo, productRepo);
            view.ShowDialog();
        }
    }
}
