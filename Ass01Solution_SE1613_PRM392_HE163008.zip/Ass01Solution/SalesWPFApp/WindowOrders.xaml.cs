﻿using DataAccess.Models;
using DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SalesWPFApp
{
    /// <summary>
    /// Interaction logic for WindowOrders.xaml
    /// </summary>
    public partial class WindowOrders : Window
    {
        readonly IOrderRepository orderRepository;
        private readonly string role = (string)Application.Current.Properties["role"];
        private readonly Memeber member = (Memeber)Application.Current.Properties["member"];
        public void LoadOrderList(string role)
        {
            if (role == "admin")
            {
                lvOrders.ItemsSource = orderRepository.GetOrders();
            }
            else
            {
                lvOrders.ItemsSource = orderRepository.GetOrdersByMember(member.MemberId);
                btnDelete.IsEnabled = false;
                btnInsert.IsEnabled = false;
                btnUpdate.IsEnabled = false;    
            }
        }

        private Order GetOrderObject()
        {
            Order order = null;

            try
            {
                order = new Order
                {
                    OrderId = int.Parse(txtOrderId.Text),
                    MemberId = int.Parse(txtMemberId.Text),
                    OrderDate = DateTime.Parse(txtOrderDate.Text),
                    RequiredDate = DateTime.Parse(txtRequiredDate.Text),
                    ShippedDate = DateTime.Parse(txtShipedDate.Text),
                    Freight = decimal.Parse(txtFreight.Text),
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Get orders");
            }
            return order;
        }

        private void BtnLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadOrderList(role);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            int isInsert = 1;
            InsertUpdateOrder view = new InsertUpdateOrder(isInsert);
            view.ShowDialog();
            LoadOrderList(role);
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Order? chosenOrder = lvOrders.SelectedItem as Order;
            if (chosenOrder != null)
            {
                int isInsert = 0;
                InsertUpdateOrder view = new InsertUpdateOrder(isInsert);
                view.DataContext = chosenOrder;
                view.ShowDialog();
                LoadOrderList(role);
            }
            else
            {
                MessageBox.Show("Pls chose one to update", "Update order");
            }

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Order order = GetOrderObject();
                orderRepository.DeleteOrder(order);
                LoadOrderList(role);
                MessageBox.Show($"{order.OrderId} deleted successfully ", "Delete order");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Delete product");
            }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e) => Close();
        public WindowOrders(IOrderRepository repository)
        {
            InitializeComponent();
            orderRepository = repository;
        }

    }
}
