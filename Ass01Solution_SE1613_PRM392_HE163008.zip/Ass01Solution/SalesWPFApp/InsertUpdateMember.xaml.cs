﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DataAccess.DAO;
using DataAccess.Models;
using DataAccess.Repository;

namespace SalesWPFApp
{
    /// <summary>
    /// Interaction logic for InsertUpdateMember.xaml
    /// </summary>
    public partial class InsertUpdateMember : Window
    {
        private readonly MemberRepository memberRepository = new MemberRepository();
        public InsertUpdateMember(int isInsert)
        {
            InitializeComponent();
            if (isInsert == 1)
            {
                BtnUpdate.IsEnabled= false;
            }
            else
            {
                BtnInsert.IsEnabled = false;
                txtMemberId.IsEnabled = false;
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Memeber member = new Memeber
            {
                MemberId = Int32.Parse(txtMemberId.Text),
                Email = txtEmail.Text,
                City = txtCity.Text,
                CompanyName = txtCompany.Text,
                Country = txtCountry.Text,
                Password = txtPassword.Text,
            };
            if (member != null)
            {
                memberRepository.UpdateMember(member);
                MessageBox.Show($"{member.MemberId} updated successfully ", "Update member");
            }
            this.Close();
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            Memeber member = new Memeber
            {
                MemberId = Int32.Parse(txtMemberId.Text),
                Email = txtEmail.Text,
                City = txtCity.Text,
                CompanyName = txtCompany.Text,
                Country = txtCountry.Text,
                Password = txtPassword.Text,
            };
            if (member != null)
            {
                Memeber _member = memberRepository.GetMemberByID(member.MemberId);
                if (_member != null)
                {
                    MessageBox.Show("Member ID is already taken. Please choose another one!");
                }
                else
                {
                    memberRepository.InsertMember(member);
                    MessageBox.Show($"{member.MemberId} inserted successfully ", "Insert member");
                }
            }
            this.Close();
        }
    }
}
