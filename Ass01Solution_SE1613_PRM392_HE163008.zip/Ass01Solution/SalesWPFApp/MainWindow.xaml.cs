﻿using DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesWPFApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly IMemberRepository memberRepo;
        private readonly IOrderRepository orderRepo;
        private readonly IProductRepository productRepo;
        /*private readonly IOrderDetailRepository orderDetailRepo;*/

        private string role = (string)Application.Current.Properties["role"];
        public MainWindow(
            IMemberRepository _memberRepo,
            IOrderRepository _orderRepo,
            IProductRepository _productRepo)
        {
            InitializeComponent();
            memberRepo = _memberRepo;
            orderRepo = _orderRepo;
            productRepo = _productRepo;
            if (role != "admin")
            {
                btn_product_window.IsEnabled=false;
            }
        }

        private void btnProduct_window(object sender, RoutedEventArgs e)
        {
            WindowProducts productsView = new WindowProducts(productRepo);
            productsView.ShowDialog();
        }

        private void btnMember_window(object sender, RoutedEventArgs e)
        {
            WindowMembers memberView = new WindowMembers(memberRepo);
            memberView.ShowDialog();
        }

        private void btnOrder_window(object sender, RoutedEventArgs e)
        {
            WindowOrders orderView = new WindowOrders(orderRepo);
            orderView.ShowDialog();
        }
    }
}
