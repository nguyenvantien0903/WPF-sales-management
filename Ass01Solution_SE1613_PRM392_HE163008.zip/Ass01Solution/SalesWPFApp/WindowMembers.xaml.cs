﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DataAccess.Models;
using DataAccess.Repository;

namespace SalesWPFApp
{
    /// <summary>
    /// Interaction logic for WindowMembers.xaml
    /// </summary>
    public partial class WindowMembers : Window
    {
        readonly IMemberRepository memberRepository;
        private string role = (string)Application.Current.Properties["role"];
        private Memeber member = (Memeber)Application.Current.Properties["member"];
        public void LoadMemberList(string role)
        {
            lvMembers.ItemsSource = memberRepository.GetMemebers();
            if (role != "admin")
            {
                btnDelete.IsEnabled = false;
            }
        }

        private Memeber GetMemberObject()
        {
            Memeber member = null;

            try
            {
                member = new Memeber
                {
                    MemberId = int.Parse(txtMemberId.Text),
                    Email = txtMemberEmail.Text,
                    CompanyName = txtMemberCompanyName.Text,
                    City = txtCity.Text,
                    Country = txtCountry.Text,
                    Password = txtPassword.Text,
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Get members");
            }
            return member;
        }

        private void BtnLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadMemberList(role);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            int isInsert = 1;
            InsertUpdateMember view = new InsertUpdateMember(isInsert);
            view.ShowDialog();
            LoadMemberList(role);
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Memeber? chosenMember = lvMembers.SelectedItem as Memeber;
            if (chosenMember != null)
            {
                int isInsert = 0;
                InsertUpdateMember view = new InsertUpdateMember(isInsert);
                view.DataContext = chosenMember;
                view.ShowDialog();
                LoadMemberList(role);
            }
            else
            {
                MessageBox.Show("Pls chose one to update", "Update member");
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Memeber member = GetMemberObject();
                if (member == null)
                {
                    MessageBox.Show("PLs chose one to delete", "Delete member");
                    return;
                }
                memberRepository.DeleteMember(member);
                LoadMemberList(role);
                MessageBox.Show($"{member.MemberId} deleted successfully ", "Delete member");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Delete member");
            }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e) => Close();
        public WindowMembers(IMemberRepository repository)
        {
            InitializeComponent();
            memberRepository= repository;
        }

    }
}
