﻿using DataAccess.DAO;
using DataAccess.Models;
using DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SalesWPFApp
{
    /// <summary>
    /// Interaction logic for InsertUpdateOrder.xaml
    /// </summary>
    public partial class InsertUpdateOrder : Window
    {
        private readonly OrderRepository orderRepository = new OrderRepository();
        public InsertUpdateOrder(int isInsert)
        {
            InitializeComponent();
            if (isInsert == 1)
            {
                BtnUpdate.IsEnabled = false;
            }
            else
            {
                BtnInsert.IsEnabled = false;
                txtOrderId.IsEnabled = false;
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Order order = new Order
            {
                OrderId = int.Parse(txtOrderId.Text),
                MemberId = int.Parse(txtMemberId.Text),
                OrderDate = DateTime.Parse(txtOrderDate.Text),
                RequiredDate = DateTime.Parse(txtRequiredDate.Text),
                ShippedDate = DateTime.Parse(txtShippedDate.Text),
                Freight = decimal.Parse(txtFreight.Text),
            };
            if (order != null)
            {
                orderRepository.UpdateOrder(order);
                MessageBox.Show($"{order.OrderId} updated successfully ", "Update order");
            }
            this.Close();
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            Order order = new Order
            {
                OrderId = int.Parse(txtOrderId.Text),
                MemberId = int.Parse(txtMemberId.Text),
                OrderDate = DateTime.Parse(txtOrderDate.Text),
                RequiredDate = DateTime.Parse(txtRequiredDate.Text),
                ShippedDate = DateTime.Parse(txtShippedDate.Text),
                Freight = decimal.Parse(txtFreight.Text),
            };
            if (order != null)
            {
                Order _order = orderRepository.GetOrderByID(order.OrderId);
                if (_order != null)
                {
                    MessageBox.Show("Order ID is already taken. Please choose another one!");
                }
                else
                {
                    orderRepository.InsertOrder(order);
                    MessageBox.Show($"{order.OrderId} inserted successfully ", "Insert order");
                }
            }
            this.Close();
        }
    }
}
