﻿using DataAccess.Models;
using DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SalesWPFApp
{
    /// <summary>
    /// Interaction logic for WindowProducts.xaml
    /// </summary>
    public partial class WindowProducts : Window
    {
        readonly IProductRepository productRepository;
        public void LoadProductList()
        {
            lvProducts.ItemsSource = productRepository.GetProducts();
        }

        private Product GetProductObject()
        {
            Product product = null;

            try
            {
                product = new Product
                {
                    ProductId = int.Parse(txtProductId.Text),
                    CategoryId = int.Parse(txtProductId.Text),
                    ProductName = txtProductName.Text,
                    Weight = txtWeight.Text,
                    UnitPrice = decimal.Parse(txtUnitPrice.Text),
                    UnitStock = int.Parse(txtUnitStock.Text),
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Get products");
            }
            return product;
        }

        private void BtnLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadProductList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchById_Click(object sender, RoutedEventArgs e)
        {
            int id = int.Parse(txtSearchById.Text);
            lvProducts.ItemsSource = new List<Product> { productRepository.GetProductByID(id) };
        }

        private void BtnSearchByProductName_Click(object sender, RoutedEventArgs e)
        {
            string productName = txtSearchByProductName.Text;
            lvProducts.ItemsSource = productRepository.GetProductByName(productName);
        }

        private void BtnSearchByUnitPrice_Click(object sender, RoutedEventArgs e)
        {
            decimal unitPrice = decimal.Parse(txtSearchByUnitPrice.Text);
            lvProducts.ItemsSource = productRepository.GetProductByUnitPrice(unitPrice);
        }

        private void BtnSearchByUnitInStock_Click(object sender, RoutedEventArgs e)
        {
            int unitInStock = int.Parse(txtSearchByUnitInStock.Text);
            lvProducts.ItemsSource = productRepository.GetProductByUnitIntock(unitInStock);
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            int isInsert = 1;
            InsertUpdateProduct view = new InsertUpdateProduct(isInsert);
            view.ShowDialog();
            LoadProductList();
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Product? chosenProduct = lvProducts.SelectedItem as Product;
            if (chosenProduct != null)
            {
                int isInsert = 0;
                InsertUpdateProduct view = new InsertUpdateProduct(isInsert);
                view.DataContext = chosenProduct;
                view.ShowDialog();
                LoadProductList();
            }
            else
            {
                MessageBox.Show("Pls chose one to update", "Update product");
            }

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Product product = GetProductObject();
                productRepository.DeleteProduct(product);
                LoadProductList();
                MessageBox.Show($"{product.ProductId} deleted successfully ", "Delete product");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Delete product");
            }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e) => Close();
        public WindowProducts(IProductRepository repository)
        {
            InitializeComponent();
            productRepository = repository;
        }
    }
}
