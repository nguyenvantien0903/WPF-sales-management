﻿using DataAccess.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.DAO
{
    public class OrderDAO
    {
        private static OrderDAO instance = null;
        public static readonly object instanceLock = new object();

        private OrderDAO() { }

        public static OrderDAO Instance
        {
            get
            {
                lock (instanceLock)
                {
                    if (instance == null)
                    {
                        instance = new OrderDAO();
                    }
                }
                return instance;
            }
        }

        public IEnumerable<Order> GetOrdersList()
        {
            List<Order> order;
            try
            {
                var dbContext = new SalesWPFAppContext();
                order = dbContext.Orders.ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return order;
        }

        public Order GetOrderByID(int id)
        {
            Order order = null;
            try
            {
                var dbContext = new SalesWPFAppContext();
                order = dbContext.Orders.FirstOrDefault(order => order.OrderId == id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return order;
        }

        public void AddNewOrder(Order order)
        {
            try
            {
                Order _order = GetOrderByID(order.OrderId);
                if (_order == null)
                {
                    var dbContext = new SalesWPFAppContext();
                    dbContext.Orders.Add(order);
                    dbContext.SaveChanges();
                }
                else
                {
                    throw new Exception("order exists");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void UpdateOrder(Order order)
        {
            try
            {
                Order _order = GetOrderByID(order.OrderId);
                if (_order != null)
                {
                    var dbContext = new SalesWPFAppContext();
                    dbContext.Entry<Order>(order).State = EntityState.Modified;
                    dbContext.SaveChanges();
                }
                else
                {
                    throw new Exception("order does not exists");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void RemoveOrder(Order order)
        {
            try
            {
                Order _order = GetOrderByID(order.OrderId);
                if (_order != null)
                {
                    var dbContext = new SalesWPFAppContext();
                    dbContext.Orders.Remove(order);
                    dbContext.SaveChanges();
                }
                else
                {
                    throw new Exception("order does not exists");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        internal IEnumerable<Order> GetOrderByMember(int memberId)
        {
            List<Order> orders;
            try
            {
                var ctx = new SalesWPFAppContext();
                DateTime startDateDefault = new DateTime(1990, 01, 01);
                DateTime endDateDefault = new DateTime(2700, 01, 01);
                orders = ctx.Orders.Where(a =>
                    a.MemberId == memberId)
                    .ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return orders;
        }
    }
}
