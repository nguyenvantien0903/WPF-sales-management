﻿using DataAccess.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.DAO
{
    public class MemberDAO
    {
        private static MemberDAO instance = null;
        public static readonly object instanceLock = new object();

        private MemberDAO() { }

        public static MemberDAO Instance
        {
            get 
            { 
                lock(instanceLock) 
                {
                    if(instance == null)
                    {
                        instance = new MemberDAO();
                    }
                } 
                return instance;
            } 
        }
        
        public IEnumerable<Memeber> GetMemebersList()
        {
            List<Memeber> members;
            try
            {
                var dbContext = new SalesWPFAppContext();
                members = dbContext.Memebers.ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return members;
        }

        public Memeber GetMemberByID(int id)
        {
            Memeber member = null;
            try
            {
                var dbContext = new SalesWPFAppContext();
                member= dbContext.Memebers.FirstOrDefault(member => member.MemberId== id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return member;
        }

        public void AddNewMember(Memeber member)
        {
            try
            {
                Memeber _member = GetMemberByID(member.MemberId);
                if (_member == null)
                {
                    var dbContext = new SalesWPFAppContext();
                    dbContext.Memebers.Add(member);
                    dbContext.SaveChanges();
                }
                else
                {
                    throw new Exception("member exists");
                }
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void UpdateMember(Memeber member)
        {
            try
            {
                Memeber _member = GetMemberByID(member.MemberId);
                if (_member != null)
                {
                    var dbContext = new SalesWPFAppContext();
                    dbContext.Entry<Memeber>(member).State = EntityState.Modified;
                    dbContext.SaveChanges();
                }
                else
                {
                    throw new Exception("member does not exists");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void RemoveMember(Memeber member)
        {
            try
            {
                Memeber _member = GetMemberByID(member.MemberId);
                if (_member != null)
                {
                    var dbContext = new SalesWPFAppContext();
                    dbContext.Memebers.Remove(member);
                    dbContext.SaveChanges();
                }
                else
                {
                    throw new Exception("member does not exists");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public Memeber GetMemberByEmail(string username, string password)
        {
            Memeber member;
            try
            {
                var dbContext = new SalesWPFAppContext();
                member = (from m in dbContext.Memebers
                          where m.Email == username & m.Password == password
                          select m).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return member;
        }
    }
}
