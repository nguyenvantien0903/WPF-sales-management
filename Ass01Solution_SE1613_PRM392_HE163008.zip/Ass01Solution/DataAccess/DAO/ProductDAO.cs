﻿using DataAccess.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.DAO
{
    public class ProductDAO
    {
        private static ProductDAO instance = null;
        public static readonly object instanceLock = new object();

        private ProductDAO() { }

        public static ProductDAO Instance
        {
            get
            {
                lock (instanceLock)
                {
                    if (instance == null)
                    {
                        instance = new ProductDAO();
                    }
                }
                return instance;
            }
        }

        public IEnumerable<Product> GetProductsList()
        {
            List<Product> members;
            try
            {
                var dbContext = new SalesWPFAppContext();
                members = dbContext.Products.ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return members;
        }

        public Product GetProductByID(int id)
        {
            Product product = null;
            try
            {
                var dbContext = new SalesWPFAppContext();
                product = dbContext.Products.FirstOrDefault(product => product.ProductId == id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return product;
        }

        public void AddNewProduct(Product product)
        {
            try
            {
                Product _product = GetProductByID(product.ProductId);
                if (_product == null)
                {
                    var dbContext = new SalesWPFAppContext();
                    dbContext.Products.Add(product);
                    dbContext.SaveChanges();
                }
                else
                {
                    throw new Exception("Product exists");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void UpdateProduct(Product product)
        {
            try
            {
                Product _product = GetProductByID(product.ProductId);
                if (_product != null)
                {
                    var dbContext = new SalesWPFAppContext();
                    dbContext.Entry<Product>(product).State = EntityState.Modified;
                    dbContext.SaveChanges();
                }
                else
                {
                    throw new Exception("product does not exists");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void RemoveProduct(Product product)
        {
            try
            {
                Product _product = GetProductByID(product.ProductId);
                if (_product != null)
                {
                    var dbContext = new SalesWPFAppContext();
                    dbContext.Products.Remove(product);
                    dbContext.SaveChanges();
                }
                else
                {
                    throw new Exception("product does not exists");
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        internal IEnumerable GetProductByName(string productName)
        {
            List<Product> _product;
            try
            {
                var dbContext = new SalesWPFAppContext();
                _product = dbContext.Products.Where(a=>
                a.ProductName.Contains(productName)).ToList();
            }
            catch (Exception ex) {
                throw new Exception(ex.Message);
            }
            return _product;
        }

        internal IEnumerable GetProductByUnitPrice(decimal unitPrice)
        {
            List<Product> _product;
            try
            {
                var dbContext = new SalesWPFAppContext();
                _product = dbContext.Products.Where(a =>
                Math.Abs(a.UnitPrice-unitPrice)<=1).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return _product;
        }

        internal IEnumerable GetProductByUnitInStock(int unitInStock)
        {
            List<Product> _product;
            try
            {
                var dbContext = new SalesWPFAppContext();
                _product = dbContext.Products.Where(a =>
                a.UnitStock.Equals(unitInStock)).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return _product;
        }
    }
}
