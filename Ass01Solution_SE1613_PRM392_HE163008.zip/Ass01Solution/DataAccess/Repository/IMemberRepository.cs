﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.DAO;
using DataAccess.Models;

namespace DataAccess.Repository
{
    public interface IMemberRepository
    {
        IEnumerable<Memeber> GetMemebers();

        Memeber GetMemberByID(int id);

        Memeber verifyMember(String username, String password);

        void InsertMember(Memeber member);

        void UpdateMember(Memeber member);

        void DeleteMember(Memeber member);

    }
}
