﻿using DataAccess.DAO;
using DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class MemberRepository : IMemberRepository
    {
        public void DeleteMember(Memeber member) => MemberDAO.Instance.RemoveMember(member);

        public Memeber GetMemberByID(int id) => MemberDAO.Instance.GetMemberByID(id);

        public IEnumerable<Memeber> GetMemebers() => MemberDAO.Instance.GetMemebersList();

        public void InsertMember(Memeber member) => MemberDAO.Instance.AddNewMember(member);

        public void UpdateMember(Memeber member) => MemberDAO.Instance.UpdateMember(member);

        public Memeber verifyMember(string username, string password) => MemberDAO.Instance.GetMemberByEmail(username, password);
    }
}
