﻿using DataAccess.DAO;
using DataAccess.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class ProductRepository : IProductRepository
    {
        public void DeleteProduct(Product product) => ProductDAO.Instance.RemoveProduct(product);

        public Product GetProductByID(int id) => ProductDAO.Instance.GetProductByID(id);

        public IEnumerable GetProductByName(string productName) => ProductDAO.Instance.GetProductByName(productName);

        public IEnumerable GetProductByUnitIntock(int unitInStock) => ProductDAO.Instance.GetProductByUnitInStock(unitInStock);

        public IEnumerable GetProductByUnitPrice(decimal unitPrice) => ProductDAO.Instance.GetProductByUnitPrice(unitPrice);

        public IEnumerable<Product> GetProducts() => ProductDAO.Instance.GetProductsList();

        public void InsertProduct(Product product) => ProductDAO.Instance.AddNewProduct(product);

        public void UpdateProduct(Product product) => ProductDAO.Instance.UpdateProduct(product);
    }
}
