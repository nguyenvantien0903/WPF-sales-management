﻿using DataAccess.DAO;
using DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class OrderRepository : IOrderRepository
    {
        public void DeleteOrder(Order order) => OrderDAO.Instance.RemoveOrder(order);

        public Order GetOrderByID(int id) => OrderDAO.Instance.GetOrderByID(id);

        public IEnumerable<Order> GetOrders() => OrderDAO.Instance.GetOrdersList();

        public IEnumerable<Order> GetOrdersByMember(int memberId) => OrderDAO.Instance.GetOrderByMember(memberId);

        public void InsertOrder(Order order) => OrderDAO.Instance.AddNewOrder(order);

        public void UpdateOrder(Order order) => OrderDAO.Instance.UpdateOrder(order);
    }
}
